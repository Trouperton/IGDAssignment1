// Copyright Epic Games, Inc. All Rights Reserved.

#include "IGDAssignment1.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, IGDAssignment1, "IGDAssignment1" );
